from pathlib import Path
import sys,subprocess,json,time
root=Path(__file__).resolve().parent
mode=sys.argv[1]
assert mode in 'ABCD'
relay=mode in 'AB';temp=mode in 'AC'
gdb='/Users/jibailey/zephyr-sdk-1.0.1/gnu/arm-zephyr-eabi/bin/arm-zephyr-eabi-gdb'
saved_temp=0x0804d0a8
script=f'''set pagination off
set confirm off
set remotetimeout 8
file {root}/zephyr.elf
target remote localhost:3333
hbreak *0x08005260
continue
if $pc != 0x08005260
  detach
  quit 1
end
printf "SAFE_BOUNDARY\\n"
bt 4
p _kernel.cpus[0].current->name
p/x 'housekeeping.c'::temperature_dev
p 'housekeeping.c'::temperature_initialized
p 'devices.c'::relay_gpio_online
set variable 'devices.c'::relay_gpio_online = {1 if relay else 0}
set variable 'housekeeping.c'::temperature_dev = (const struct device *){hex(saved_temp) if temp else '0'}
p/x 'housekeeping.c'::temperature_dev
p 'devices.c'::relay_gpio_online
p 'housekeeping.c'::last_sample_ms
p 'housekeeping.c'::relay_response_deadline_ms
p cal.state
p cal.record_count
p/x ((struct uart_stm32_config *)modbus_serial_cfg.dev->config)->usart
delete breakpoints
monitor rmbreak 0x08005260
monitor lsbreak
detach
quit
'''
f=root/f'transition_{mode}_{time.time_ns()}.gdb';f.write_text(script)
t=time.monotonic()
r=subprocess.run([gdb,'-q','-batch','-x',str(f)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=20)
f.with_suffix('.log').write_text(r.stdout)
print(r.stdout,flush=True)
if r.returncode or 'SAFE_BOUNDARY' not in r.stdout or 'Error in sourced command' in r.stdout:
 raise RuntimeError('Transition must be inspected before starting queries')
with (root/'transitions.jsonl').open('a') as o:o.write(json.dumps({'mode':mode,'start':t,'end':time.monotonic(),'relay':relay,'temperature':temp,'log':str(f.with_suffix('.log'))})+'\n')
time.sleep(5)
