import sys,time,subprocess,json,signal
from pathlib import Path
root=Path(__file__).resolve().parent
label=sys.argv[1]
gdb='/Users/jibailey/zephyr-sdk-1.0.1/gnu/arm-zephyr-eabi/bin/arm-zephyr-eabi-gdb'
with (root/(label+'_ore.log')).open('w') as f:
 p=subprocess.Popen([gdb,'-q','-batch','-x',str(root/'capture_ore.gdb')],stdout=f,stderr=subprocess.STDOUT)
 try:
  time.sleep(3)
  if p.poll() is not None:
   print('Pre-trigger event; inspect before retry',flush=True)
   sys.exit(2)
  t=time.monotonic()
  print('Beginning capture queries '+label,flush=True)
  q=subprocess.run([sys.executable,str(root/'query_block.py'),label,'--count','120'])
  if p.poll() is None:
   p.send_signal(signal.SIGINT)
   p.wait(timeout=10)
  (root/(label+'_ore_meta.json')).write_text(json.dumps({'query_start_mono':t,'query_end_mono':time.monotonic(),'gdb_rc':p.returncode,'query_rc':q.returncode}))
  print('GDB result '+str(p.returncode),flush=True)
 finally:
  if p.poll() is None:
   p.send_signal(signal.SIGINT)
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=5)
