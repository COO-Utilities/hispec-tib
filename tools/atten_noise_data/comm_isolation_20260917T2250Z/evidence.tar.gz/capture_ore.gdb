set pagination off
set confirm off
set remotetimeout 8
file /private/tmp/hispec-isolation-7ysagpcj/zephyr.elf
set mem inaccessible-by-default off
target remote localhost:3333
hbreak *0x0804a50a
continue
printf "UART_OVERRUN_CLEAR_PATH\n"
info registers r0 r1 r2 r3 r4 r5 r6 r7 r8 r9 r10 r11 r12 sp lr pc xpsr
bt 30
p _kernel.cpus[0].current->name
p/x modbus_serial_cfg.uart_buf_ctr
x/24bx modbus_serial_cfg.uart_buf
p mb_ctx_tbl[0].tx_adu.unit_id
p mb_ctx_tbl[0].tx_adu.fc
p mb_ctx_tbl[0].tx_adu.length
x/8bx mb_ctx_tbl[0].tx_adu.data
p mb_ctx_tbl[0].rx_adu_err
p/x mb_ctx_tbl[0].state
p 'devices.c'::relay_gpio_online
p/x 'housekeeping.c'::temperature_dev
monitor read32 0x40004400 12
monitor read32 0x4000441c 4
delete breakpoints
monitor rmbreak 0x0804a50a
monitor lsbreak
detach
quit
