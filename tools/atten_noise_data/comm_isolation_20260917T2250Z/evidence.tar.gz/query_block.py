import sys,time,json,random,logging,argparse
from pathlib import Path
from hispec_fibpcb import HispecFibPcb
p=argparse.ArgumentParser();p.add_argument('block');p.add_argument('--count',type=int,default=250);args=p.parse_args()
root=Path(__file__).resolve().parent
logging.basicConfig(filename=root/'host_warnings.log',level=logging.WARNING)
rng=random.Random(20260917)
failed=0;start=time.monotonic()
with HispecFibPcb('hispec.caltech.edu',client_id='codex-isolation-'+args.block,timeout_s=8) as pcb, (root/(args.block+'.jsonl')).open('w',buffering=1) as f:
 before=pcb._request_json('status');f.write(json.dumps({'kind':'status_before','data':before,'mono':time.monotonic()})+'\n')
 for i in range(args.count):
  t=time.monotonic()
  try:
   data=pcb._request_json('laser/status',{'name':'1028y'})
   ok=data.get('read_rc',0)==0
   if data.get('op_started') or abs(data.get('curr_meas_ma',0))>.2:
    raise RuntimeError('Unexpected active laser; stop read burst and inspect state')
  except Exception as e:
   ok=False;data={'exception':type(e).__name__,'error':str(e)}
   if 'Unexpected active' in str(e): raise
  failed+=not ok
  f.write(json.dumps({'kind':'query','block':args.block,'i':i,'mono':t,'end':time.monotonic(),'ok':ok,'data':data})+'\n')
  if not ok or (i+1)%50==0: print(json.dumps({'block':args.block,'done':i+1,'failed':failed,'elapsed_s':round(time.monotonic()-start,2),'last':None if ok else data}),flush=True)
  time.sleep(rng.uniform(0,.05))
 after=pcb._request_json('status');f.write(json.dumps({'kind':'status_after','data':after,'mono':time.monotonic()})+'\n')
 assert before['boots']==after['boots'],'Reboot invalidates block'
 print(json.dumps({'block':args.block,'total':args.count,'failed':failed,'boots':after['boots'],'elapsed_s':round(time.monotonic()-start,2)}),flush=True)
