import serial, time, json
from pathlib import Path
root=Path(__file__).resolve().parent
s=serial.Serial(port=None,baudrate=115200,timeout=.2)
s.dtr=False;s.rts=False;s.port='/dev/cu.usbmodem1203';s.open()
print('Serial capture started; DTR/RTS disabled; no serial writes.',flush=True)
with (root/'serial.jsonl').open('a',buffering=1) as f:
 while not (root/'stop_serial').exists():
  b=s.readline()
  if b: f.write(json.dumps({'mono':time.monotonic(),'wall':time.time(),'line':b.decode(errors='replace').rstrip()})+'\n')
s.close()
print('Serial capture stopped',flush=True)
