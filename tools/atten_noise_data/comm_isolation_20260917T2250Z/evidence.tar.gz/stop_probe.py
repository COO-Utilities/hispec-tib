import json,time
from pathlib import Path
from hispec_fibpcb import HispecFibPcb
root=Path(__file__).resolve().parent
with HispecFibPcb('hispec.caltech.edu',client_id='codex-isolation-stop',timeout_s=8) as pcb, (root/'stop_probe.jsonl').open('w',buffering=1) as f:
 for i in range(3):
  for endpoint,payload in [('laser',{'name':'1028y','stop':True}),('laser/status',{'name':'1028y'})]:
   t=time.monotonic()
   data=pcb._request_json(endpoint,payload)
   row={'i':i,'endpoint':endpoint,'request':payload,'mono':t,'end':time.monotonic(),'data':data}
   f.write(json.dumps(row,default=lambda v:vars(v))+'\n');print(json.dumps(row,default=lambda v:vars(v)),flush=True)
  time.sleep(1)
