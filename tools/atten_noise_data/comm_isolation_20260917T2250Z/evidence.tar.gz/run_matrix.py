import sys,subprocess,time,json
from pathlib import Path
root=Path(__file__).resolve().parent
try:
 for block in ['D1','C1','A2','C2','D2','B2','A3']:
  print('Transition '+block,flush=True)
  r=subprocess.run([sys.executable,str(root/'set_condition.py'),block[0]],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  (root/(block+'_transition.log')).write_text(r.stdout)
  r.check_returncode()
  r=subprocess.run([sys.executable,str(root/'query_block.py'),block,'--count','250'])
  r.check_returncode()
finally:
 r=subprocess.run([sys.executable,str(root/'set_condition.py'),'A'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (root/'restore_A.log').write_text(r.stdout)
 print('RESTORE_A returncode='+str(r.returncode),flush=True)
 r.check_returncode()
