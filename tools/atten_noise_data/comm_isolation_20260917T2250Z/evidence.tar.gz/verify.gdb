set pagination off
set confirm off
set remotetimeout 8
file /private/tmp/hispec-isolation-7ysagpcj/zephyr.elf
target remote localhost:3333
dump binary memory /private/tmp/hispec-isolation-7ysagpcj/flash-readback.bin 0x08000000 0x8061378
p/x 'housekeeping.c'::temperature_dev
p 'housekeeping.c'::temperature_initialized
p 'devices.c'::relay_gpio_online
p _kernel.cpus[0].current->name
info registers pc lr xpsr
p/x *(unsigned int *)0x40004400
p/x *(unsigned int *)0x4000441c
p _kernel.cpus[0].current->base.prio
info threads
monitor resume
detach
quit
