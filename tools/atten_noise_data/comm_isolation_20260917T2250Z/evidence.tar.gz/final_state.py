import json,time,dataclasses
from pathlib import Path
from hispec_fibpcb import HispecFibPcb
root=Path(__file__).resolve().parent
with HispecFibPcb('hispec.caltech.edu',client_id='codex-isolation-final',timeout_s=8) as pcb:
 for name,fn in [('status',pcb.status),('settings',lambda:pcb.laser_settings('1028y')),('atten',lambda:pcb.atten('1028y')),('heater',pcb.laser_bankheater),('bank',pcb.laser_bankpower),('engineering',lambda:pcb.laser_status('1028y'))]:
  for attempt in range(3):
   try:
    d=fn();d=dataclasses.asdict(d) if dataclasses.is_dataclass(d) else d
    break
   except Exception as e:
    print(name,'attempt',attempt,repr(e),flush=True)
    if attempt==2:raise
    time.sleep(.5)
  (root/(name+'_final.json')).write_text(json.dumps(d,indent=2)+'\n')
  print(name,json.dumps(d),flush=True)
for name in ['settings','atten','bank']:
 initial=json.loads((root/(name+'_initial.json')).read_text());final=json.loads((root/(name+'_final.json')).read_text())
 print(name,'unchanged',initial==final,flush=True)
 if initial!=final:print('DIFF',{k:(initial.get(k),final.get(k)) for k in initial.keys()|final.keys() if initial.get(k)!=final.get(k)},flush=True)
