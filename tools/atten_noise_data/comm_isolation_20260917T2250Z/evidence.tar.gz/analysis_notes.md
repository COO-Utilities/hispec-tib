# Communication isolation notes — 2026-09-17

Investigation complete. Final findings and cleanup are recorded in report.md.

## Method

- MCU boot counter 37; firmware reports 620d711a0244-dirty.
- Attached ST-Link with pyOCD in attach-only mode; no reset/load/flash. Full 398200-byte flash readback equals saved build binary, SHA256 a8207361eb9d9db563888065226d0e015ad94f2cdc8f0b369f9f352f8838c0b0. See flash-match.json and verify.log.
- Saved ELF, config, source snapshots and host module before probes. Source repository was being edited independently during the investigation.
- Laser 1028y off, TEC off, measured current zero. Photodiodes off. No calibration or laser start.
- All measured host requests: laser/status, name 1028y. One engineering query comprises multiple Modbus transactions; percentages are failed engineering queries, not failed individual transactions.
- Fixed RNG seed supplies 0–50 ms gaps. Each measured block has 250 queries and before/after firmware/boot checks. All gate transitions are outside measured blocks; no breakpoints or debugger halts occur inside those blocks. Five-second settling delay follows each transition.
- A: relay and temperature enabled; B: relay only; C: temperature only; D: neither.
- Gates are existing RAM state: devices.c relay_gpio_online (original true) and housekeeping.c temperature_dev (original 0x0804d0a8). temperature_initialized remains true. Changes occur at temperature_work_handler entry, hardware breakpoint 0x08005260, before transfers start. GDB scripts and transition logs retain before/after values.
- Order: detached baseline, A1, B1, D1, C1, A2, C2, D2, B2, A3; restore A afterward.
- Temperature-off conditions remove the 750 ms conversion sleep, so relay-only cadence is approximately 1 s versus 1.75 s normally. This experiment establishes whether each path can cause faults; its rates do not estimate each path's contribution under the normal schedule.
- Host serial receipt timestamps can lag firmware log timestamps in USB batches. Query success/failure comes from MQTT responses; serial timestamps/return codes supply mechanism evidence. Do not treat approximate serial error counts as identical to query counts (background firmware traffic also exists).

## Source evidence

- zephyr/drivers/w1/w1_zephyr_gpio.c: reset masks interrupts across 480 + 70 + 410 microseconds (plus execution overhead). Config enables critical sections.
- USART2 Modbus at 115200 8N1: a character arrives every 86.8 microseconds. FIFO is disabled in this build.
- zephyr/drivers/serial/uart_stm32.c fifo_read clears ORE without reporting it to Modbus. Saved ELF places the overrun-only clear instruction at 0x0804a50a; the preceding branch skips it when ORE is clear.
- zephyr/subsys/modbus/modbus_serial.c: truncated frame returns -EMSGSIZE (-122); bad CRC returns -EIO (-5); no response times out (-116).
- hispec-tib commit 9cc7a524 (Sep 15) added unconditional periodic relay reads to housekeeping. Temperature-only polling predates that addition. New exposure to an existing interrupt blackout is plausible; this is not proof of the exact first faulty flash.
- Between pinned Zephyr e60d3379133c4315504e9113ecdcc05fbe552756 and proposed 55303e23f59df42d3ba41f0e93ca2192240f804a, the relevant changes are the optional Modbus workqueue, include formatting, and GPIO-init logging. Reset critical timing and RTU frame ownership are not fixed.

## Distinct stale-health warning

Restoring relay polling after deliberately suppressing it produced:

    00:10:54.322 relay_communication_fault rc=-116
    00:10:54.326 relay_communication_recovered rc=0

housekeeping.c checks its five-second response deadline BEFORE performing the port read. The successful first read immediately clears the warning. This demonstrates that the warning pair need not represent a timed-out relay transaction.

Laser health uses the same check-before-read pattern. Calibration fitting runs synchronously in the priority-3 throughput thread; these checks run on priority-7 app_blocking. Numerical fitting has no sleeps/yields. The supplied DAC1/DAC2 fit warnings were 5272 ms apart, longer than the five-second deadline. This strongly supports delayed health work as the cause of that later warning pair, but the original fitting interval has not been profiled on this boot (retained calibration is inactive/empty).

## Independent RTU race

The existing timer callback queues parser work without freezing RX; later bytes can alter the shared buffer and rearm the timer before parsing completes. Application transaction serialization cannot serialize ISR/timer/workqueue ownership. The polling experiment must not be represented as proving which -122 instances come from this separate race. A truncated frame from UART overrun is already sufficient to produce -122.

## Direct hardware captures

Both relay_ore_ore.log and temperature_ore_ore.log stopped at 0x0804a50a, the overrun-only USART2 clear instruction, during a node-5 function-3 read. r3=0x40004400, r1=8, r5=0xa0000000, xPSR=0xa100004b. The branch had already tested ORE before the first breakpoint halt, so the existence of the first overrun is not caused by that halt. Each capture was armed while idle and ran for three seconds before the host query burst; neither triggered during that pre-trigger interval.

Relay-only interrupted stack: temperature_work_handler -> gpio_port_get_raw -> ds2408_port_get_raw -> ds2408_read_reg -> w1_write_read -> reset_select -> skip_rom -> w1_gpio_reset_bus (returning after irq_unlock), then USART2 ISR. Active request: node 5, read register 0x0041, count 1. Temperature pointer NULL.

Temperature-only interrupted stack: temperature_work_handler -> temperature_sample_once -> sensor_sample_fetch -> ds18b20_sample_fetch -> ds18b20_temperature_convert -> w1_reset_select -> reset_select -> skip_rom -> w1_gpio_reset_bus (returning after irq_unlock), then USART2 ISR. Active request: node 5, read register 0x008a, count 1. relay_gpio_online=false.

CR1 readback 0x0000002d confirms FIFOEN is clear; CR2 and CR3 are zero. ISR after halting is 0x006210da (ORE set); use the pre-halt taken branch as the primary overrun evidence because later register reads can be affected by halting.

Hardware breakpoint explicitly removed and flushed; both captures conclude with 8 hardware breakpoints available / No breakpoints installed. Capture-query failure rates are excluded from the matrix because these runs intentionally halt the CPU.
