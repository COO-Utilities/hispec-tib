set pagination off
set confirm off
set remotetimeout 8
file /private/tmp/hispec-isolation-7ysagpcj/zephyr.elf
target remote localhost:3333
hbreak *0x08005260
continue
if $pc != 0x08005260
  detach
  quit 1
end
printf "SAFE_BOUNDARY\n"
bt 4
p _kernel.cpus[0].current->name
p/x 'housekeeping.c'::temperature_dev
p 'housekeeping.c'::temperature_initialized
p 'devices.c'::relay_gpio_online
set variable 'devices.c'::relay_gpio_online = 0
set variable 'housekeeping.c'::temperature_dev = (const struct device *)0x804d0a8
p/x 'housekeeping.c'::temperature_dev
p 'devices.c'::relay_gpio_online
p 'housekeeping.c'::last_sample_ms
p 'housekeeping.c'::relay_response_deadline_ms
p cal.state
p cal.record_count
p/x ((struct uart_stm32_config *)modbus_serial_cfg.dev->config)->usart
delete breakpoints
monitor rmbreak 0x08005260
monitor lsbreak
detach
quit
